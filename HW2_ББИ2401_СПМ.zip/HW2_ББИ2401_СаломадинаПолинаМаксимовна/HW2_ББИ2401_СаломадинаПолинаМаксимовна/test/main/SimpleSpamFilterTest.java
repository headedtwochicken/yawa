package main;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class SimpleSpamFilterTest {
    @Test
    void detectsSimpleSpam() {
        User polina = new User("polina", null);
        User vera = new User("vera", null);
        SimpleSpamFilter filter = new SimpleSpamFilter();
        Message m1 = new Message("Spam Alert", "hello", polina, vera);
        Message m2 = new Message("Hello", "contains SPAM here", polina, vera);
        Message m3 = new Message("Hi", "friendly message", polina, vera);
        assertTrue(filter.isSpam(m1));
        assertTrue(filter.isSpam(m2));
        assertFalse(filter.isSpam(m3));
    }
}
