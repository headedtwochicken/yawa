package main;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.*;

class CompositeSpamFilterTest {
    @Test
    void combinesFilters() {
        User polina = new User("polina", null);
        User vera = new User("vera", null);
        SimpleSpamFilter simple = new SimpleSpamFilter();
        SenderSpamFilter sender = new SenderSpamFilter("polina");
        List<SpamFilter> list = new ArrayList<>();
        list.add(simple);
        list.add(sender);
        CompositeSpamFilter composite = new CompositeSpamFilter(list);
        Message m1 = new Message("Hello", "no spam here", polina, vera);
        Message m2 = new Message("Spam Offer", "text", vera, polina);
        Message m3 = new Message("Hi", "clean message", vera, polina);
        assertTrue(composite.isSpam(m1));
        assertTrue(composite.isSpam(m2));
        assertFalse(composite.isSpam(m3));
    }
}