package main;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.*;

class KeywordsSpamFilterTest {
    @Test
    void testSpam() {
        KeywordsSpamFilter filter = new KeywordsSpamFilter(Set.of("spam", "кредит"));
        Message spam1 = new Message("SPAM Alert", "Hello", null, null);
        assertTrue(filter.isSpam(spam1));
        Message spam2 = new Message("Важно", "Получите кредит сейчас!", null, null);
        assertTrue(filter.isSpam(spam2));
    }

    @Test
    void testNoSpam() {
        KeywordsSpamFilter filter = new KeywordsSpamFilter(Set.of("кредит"));
        Message normal1 = new Message("Объявнение", "Кредитование доступно", null, null);
        assertFalse(filter.isSpam(normal1));
    }
}