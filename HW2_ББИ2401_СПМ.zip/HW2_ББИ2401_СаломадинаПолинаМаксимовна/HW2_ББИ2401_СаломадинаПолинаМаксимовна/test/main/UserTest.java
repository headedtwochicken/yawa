package main;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.*;

class UserTest {
    @Test
    void testSendMessage() {
        User polina = new User("polina", null);
        User vera = new User("vera", null);
        polina.sendMessage("Hi", "Hey vera", vera);
        assertEquals(1, polina.getOutbox().size());
        assertEquals(1, vera.getInbox().size());
        Message m = vera.getInbox().getFirst();
        assertEquals("Hi", m.getCaption());
        assertEquals("Hey vera", m.getText());
    }

    @Test
    void testSpamFilter() {
        User polina = new User("polina", null);
        User vera = new User("vera", new SimpleSpamFilter());
        polina.sendMessage("Offer", "This is spam message", vera);
        assertEquals(1, vera.getSpam().size());
        assertTrue(vera.getInbox().isEmpty());
    }

    @Test
    void testSetFirstFilter() {
        User user = new User("polina", null);
        SpamFilter filter = new SimpleSpamFilter();
        user.setSpamFilter(filter);
        assertSame(filter, user.getSpamFilter(), "Первый фильтр должен быть установлен");
    }

    @Test
    void testSetSecondFilter() {
        User user = new User("vera", null);
        SpamFilter filter1 = new SimpleSpamFilter();
        SpamFilter filter2 = new KeywordsSpamFilter(Set.of("spam"));
        user.setSpamFilter(filter1);
        user.setSpamFilter(filter2);
        assertInstanceOf(CompositeSpamFilter.class, user.getSpamFilter(), "Должен создаться CompositeSpamFilter");
        CompositeSpamFilter composite = (CompositeSpamFilter) user.getSpamFilter();
        assertEquals(2, composite.getFilters().size(), "Composite должен содержать 2 фильтра");
        assertTrue(composite.getFilters().contains(filter1), "Первый фильтр должен быть в Composite");
        assertTrue(composite.getFilters().contains(filter2), "Второй фильтр должен быть в Composite");
    }

    @Test
    void testSetThirdFilter() {
        User user = new User("misha", null);
        SpamFilter filter1 = new SimpleSpamFilter();
        SpamFilter filter2 = new KeywordsSpamFilter(Set.of("spam"));
        SpamFilter filter3 = new SenderSpamFilter("evilUser");
        user.setSpamFilter(filter1);
        user.setSpamFilter(filter2);
        user.setSpamFilter(filter3);
        CompositeSpamFilter composite = (CompositeSpamFilter) user.getSpamFilter();
        assertEquals(3, composite.getFilters().size(), "Composite должен содержать 3 фильтра");
        assertTrue(composite.getFilters().contains(filter3), "Третий фильтр должен бытm в Composite");
    }
}