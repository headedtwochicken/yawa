package main;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class SenderSpamFilterTest {
    @Test
    void blockSender() {
        User polina = new User("polina", null);
        User vera = new User("vera", null);
        SenderSpamFilter filter = new SenderSpamFilter("polina");
        Message m1 = new Message("Hi", "шугрыд", polina, vera);
        Message m2 = new Message("Hi", "гшкра", vera, polina);
        assertTrue(filter.isSpam(m1));
        assertFalse(filter.isSpam(m2));
    }
}