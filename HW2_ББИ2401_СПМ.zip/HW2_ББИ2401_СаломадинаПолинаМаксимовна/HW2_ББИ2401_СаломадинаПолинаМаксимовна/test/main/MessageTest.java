package main;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class MessageTest {
    @Test
    void testGetters() {
        User sender = new User("polina", null);
        User receiver = new User("vera", null);
        Message msg = new Message("Hello", "World", sender, receiver);
        assertEquals("Hello", msg.getCaption());
        assertEquals("World", msg.getText());
        assertSame(sender, msg.getSender());
        assertSame(receiver, msg.getReceiver());
    }
}