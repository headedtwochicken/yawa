package main;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class RepetitionSpamFilterTest {
    @Test
    void flagsRepetition() {
        User polina = new User("polina", null);
        User vera = new User("polina", null);
        RepetitionSpamFilter filter = new RepetitionSpamFilter(2);
        Message m1 = new Message("Rep", "a_a+a b", polina, vera);
        Message m2 = new Message("Rep", "a _a _b b_", polina, vera);
        assertTrue(filter.isSpam(m1));
        assertFalse(filter.isSpam(m2));
    }
}