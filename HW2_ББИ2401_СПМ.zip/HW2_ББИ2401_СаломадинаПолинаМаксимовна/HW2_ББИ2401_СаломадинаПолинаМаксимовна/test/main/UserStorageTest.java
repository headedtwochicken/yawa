package main;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class UserStorageTest {
    @Test
    void addExists() {
        UserStorage storage = new UserStorage();
        assertFalse(storage.userExists("polina"));
        User polina = new User("polina", null);
        storage.addUser(polina);
        assertTrue(storage.userExists("polina"));
        assertSame(polina, storage.getUserByName("polina"));
    }

    @Test
    void getALLUsers() {
        UserStorage storage = new UserStorage();
        assertTrue(storage.getAllUsers().isEmpty());
        storage.addUser(new User("polina", null));
        storage.addUser(new User("vera", null));
        assertEquals(2, storage.getAllUsers().size());
    }

    @Test
    void nameNotFound() {
        UserStorage storage = new UserStorage();
        assertNull(storage.getUserByName("iusdhbsik"));
    }

    @Test
    public void addTwiceException() {
        UserStorage storage = new UserStorage();
        User polina1 = new User("polina", null);
        User polina2 = new User("polina", null);
        storage.addUser(polina1);
        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> storage.addUser(polina2)
        );
        assertEquals("Пользователь polina уже существует", exception.getMessage());
    }
}