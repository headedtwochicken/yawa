package main;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import java.io.*;
import static org.junit.jupiter.api.Assertions.*;

class MainTest {
    private final InputStream systemIn = System.in;
    private final PrintStream systemOut = System.out;
    private ByteArrayOutputStream outContent;

    @AfterEach
    void restore() {
        System.setIn(systemIn);
        System.setOut(systemOut);
    }

    private void execute(String... lines) {
        String input = String.join(System.lineSeparator(), lines);
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        Main.main(new String[]{});
    }

    @Test
    void addList() {
        execute(
                "add", "polina",
                "list",
                "quit"
        );
        String out = outContent.toString();
        assertTrue(out.contains("Пользователь polina добавлен"));
        assertTrue(out.contains("""
                Список пользователей:
                polina
                всего пользователей: 1"""));
    }

    @Test
    void invalidCommand1(){
        execute(
                "uishv",
                "quit"
        );
        String out = outContent.toString();
        assertTrue(out.contains("Выберите команду из ранее предложенных"));
    }

    @Test
    void addTwice() {
        execute(
                "add", "polina",
                "add", "polina",
                "quit"
        );
        String out = outContent.toString();
        assertTrue(out.contains("Пользователь polina добавлен"));
        assertTrue(out.contains("Ошибка: Пользователь polina уже существует"));
    }

    @Test
    void sendNone() {
        execute(
                "send", "ajncakjbv",
                "quit"
        );
        String out = outContent.toString();
        assertTrue(out.contains("Ошибка: Пользователь не найден"));
    }

    @Test
    void showEmptyInbox() {
        execute(
                "add", "polina",
                "inbox", "polina",
                "quit"
        );
        String out = outContent.toString();
        assertTrue(out.contains("== Входящие сообщения отсутствуют =="));
    }

    @Test
    void showEmptyOutbox() {
        execute(
                "add", "polina",
                "outbox", "polina",
                "quit"
        );
        String out = outContent.toString();
        assertTrue(out.contains("== Исходящие сообщения отсутствуют =="));
    }

    @Test
    void showEmptySpam() {
        execute(
                "add", "polina",
                "spam", "polina",
                "quit"
        );
        String out = outContent.toString();
        assertTrue(out.contains("== Спам отсутствует =="));
    }

    @Test
    void setFilterInvalid() {
        execute(
                "add", "polina",
                "setfilter", "polina", "iauhvbaj", "done",
                "quit"
        );
        String out = outContent.toString();
        assertTrue(out.contains("Неверный тип фильтра, попробуйте снова или введите done"));
    }

    @Test
    void setFilterKeywordsEmpty() {
        execute(
                "add", "polina",
                "setfilter", "polina", "keywords", "",
                "quit"
        );
        String out = outContent.toString();
        assertTrue(out.contains("Ошибка: Набор ключевых слов пуст"));
    }

    @Test
    void setFilterRepetition1() {
        execute(
                "add", "polina",
                "setfilter", "polina", "repetition", "jsabhd",
                "quit"
        );
        String out = outContent.toString();
        assertTrue(out.contains("Ошибка: Неверный формат числа"));
    }

    @Test
    void setFilterRepetition2() {
        execute(
                "add", "polina",
                "setfilter", "polina", "repetition", "0",
                "quit"
        );
        String out = outContent.toString();
        assertTrue(out.contains("Ошибка: Число должно быть положительным"));
    }

    @Test
    void setFilterSenderEmpty() {
        execute(
                "add", "polina",
                "setfilter", "polina", "sender", "",
                "quit"
        );
        String out = outContent.toString();
        assertTrue(out.contains("Ошибка: Такого отправителя не существует"));
    }
}