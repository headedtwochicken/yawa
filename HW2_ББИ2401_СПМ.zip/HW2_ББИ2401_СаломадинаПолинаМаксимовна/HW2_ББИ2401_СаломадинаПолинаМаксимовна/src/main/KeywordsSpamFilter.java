package main;

import java.util.*;

public class KeywordsSpamFilter implements SpamFilter {
    private final Set<String> keywords;

    public KeywordsSpamFilter(Set<String> keywords) {
        this.keywords = new HashSet<>();
        for (String keyword : keywords) {
            this.keywords.add(keyword.toLowerCase());
        }
    }

    @Override
    public boolean isSpam(Message message) {
        Set<String> messageWords = getNormalizedWords(message.getText() + " " + message.getCaption());
        return keywords.stream().anyMatch(messageWords::contains);
    }

    private Set<String> getNormalizedWords(String text) {
        String[] words = text.toLowerCase().split("[^a-zA-Z0-9а-яА-Я]+");
        return new HashSet<>(Arrays.asList(words));
    }
}