package main;
import java.util.*;

public class UserStorage {
    private Map<String, User> users;

    public UserStorage() {
        this.users = new HashMap<>();
    }

    public void addUser(User user) {
        if (users.containsKey(user.getUserName())) {
            throw new IllegalArgumentException("Пользователь " + user.getUserName() + " уже существует");
        }
        users.put(user.getUserName(), user);
    }

    public User getUserByName(String userName) {
        return users.get(userName);
    }

    public boolean userExists(String userName) {
        return users.containsKey(userName);
    }

    public Collection<User> getAllUsers() {
        return users.values();
    }
}