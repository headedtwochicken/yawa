package main;
import java.util.*;

public class Message {
    private final String caption;
    private final String text;
    private final User sender;
    private final User receiver;

    public Message(String caption, String text, User sender, User receiver) {
        this.caption = caption;
        this.text = text;
        this.sender = sender;
        this.receiver = receiver;
    }

    public String getCaption() {
        return caption;
    }

    public String getText() {
        return text;
    }

    public User getSender() {
        return sender;
    }

    public User getReceiver() {
        return receiver;
    }

    public static Message readFromConsole(Scanner scanner, UserStorage storage) {
        System.out.print("Введите имя отправителя: ");
        String sName = scanner.nextLine().trim();
        if (!storage.userExists(sName)) {
            throw new IllegalArgumentException("Пользователь не найден");
        }
        User sender = storage.getUserByName(sName);
        System.out.print("Введите имя получателя: ");
        String rName = scanner.nextLine().trim();
        if (!storage.userExists(rName)) {
            throw new IllegalArgumentException("Получатель не найден");
        }
        User receiver = storage.getUserByName(rName);
        System.out.print("Введите заголовок сообщения: ");
        String caption = scanner.nextLine().trim();
        System.out.print("Введите текст сообщения: ");
        String text = scanner.nextLine().trim();
        return new Message(caption, text, sender, receiver);
    }
}