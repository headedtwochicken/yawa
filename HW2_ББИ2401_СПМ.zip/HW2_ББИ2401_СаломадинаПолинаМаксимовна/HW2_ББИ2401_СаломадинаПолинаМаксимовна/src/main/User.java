package main;
import java.util.*;

public class User {
    private final String userName;
    private List<Message> inbox;
    private List<Message> outbox;
    private List<Message> spam;
    private SpamFilter spamFilter;

    public User(String userName, SpamFilter spamFilter) {
        this.userName = userName;
        this.inbox = new ArrayList<>();
        this.outbox = new ArrayList<>();
        this.spam = new ArrayList<>();
        this.spamFilter = spamFilter;
    }

    public String getUserName() {
        return userName;
    }

    public List<Message> getInbox() {
        return new ArrayList<>(inbox);
    }

    public List<Message> getOutbox() {
        return new ArrayList<>(outbox);
    }

    public List<Message> getSpam() {
        return new ArrayList<>(spam);
    }

    public SpamFilter getSpamFilter() {
        return spamFilter;
    }

    public void setSpamFilter(SpamFilter newFilter) {
        if (this.spamFilter instanceof CompositeSpamFilter composite) {
            composite.addFilter(newFilter);
        } else if (this.spamFilter != null) {
            List<SpamFilter> filters = new ArrayList<>();
            filters.add(this.spamFilter);
            filters.add(newFilter);
            this.spamFilter = new CompositeSpamFilter(filters);
        } else {
            this.spamFilter = newFilter;
        }
    }

    public void sendMessage(String caption, String text, User receiver) {
        Message message = new Message(caption, text, this, receiver);
        if (receiver.spamFilter != null && receiver.spamFilter.isSpam(message)) {
            receiver.spam.add(message);
        } else {
            receiver.inbox.add(message);
        }
        this.outbox.add(message);
    }
}