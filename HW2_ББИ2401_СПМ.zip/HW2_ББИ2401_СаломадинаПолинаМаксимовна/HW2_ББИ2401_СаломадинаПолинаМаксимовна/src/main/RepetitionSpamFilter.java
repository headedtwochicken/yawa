package main;
import java.util.*;

public class RepetitionSpamFilter implements SpamFilter {
    private int maxRepetitions;

    public RepetitionSpamFilter(int maxRepetitions) {
        this.maxRepetitions = maxRepetitions;
    }

    @Override
    public boolean isSpam(Message message) {
        String[] words = message.getText().toLowerCase().split("[^a-zA-Z0-9а-яА-Я]+");
        Map<String, Integer> frequencyMap = new HashMap<>();

        for (String word : words) {
            if (word.isEmpty()) continue;
            frequencyMap.put(word, frequencyMap.getOrDefault(word, 0) + 1);
            if (frequencyMap.get(word) > maxRepetitions) {
                return true;
            }
        }

        return false;
    }
}