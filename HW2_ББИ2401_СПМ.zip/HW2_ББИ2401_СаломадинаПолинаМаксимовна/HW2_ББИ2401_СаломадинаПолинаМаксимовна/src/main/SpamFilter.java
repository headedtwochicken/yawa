package main;

public interface SpamFilter {
    boolean isSpam(Message message);
}