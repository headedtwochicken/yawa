package main;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        UserStorage userStorage = new UserStorage();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите команду (add, send, inbox, outbox, setfilter, list, spam, quit):");
        while (true) {
            System.out.print("—> ");
            String command = scanner.nextLine().trim();
            try {
                switch (command) {
                    case "add":
                        addUser(userStorage, scanner);
                        break;
                    case "send":
                        sendMessage(userStorage, scanner);
                        break;
                    case "inbox":
                        showInbox(userStorage, scanner);
                        break;
                    case "outbox":
                        showOutbox(userStorage, scanner);
                        break;
                    case "setfilter":
                        setFilter(userStorage, scanner);
                        break;
                    case "list":
                        listUsers(userStorage);
                        break;
                    case "spam":
                        processSpam(userStorage, scanner);
                        break;
                    case "quit":
                        System.out.println("Почтовый сервер завершен");
                        return;
                    default:
                        System.out.println("Выберите команду из ранее предложенных");
                }
            } catch (Exception ex) {
                System.out.println("Ошибка: " + ex.getMessage());
            }
        }
    }

    private static void listUsers(UserStorage userStorage) {
        System.out.println("Список пользователей:");
        for (User user : userStorage.getAllUsers()) {
            System.out.println(user.getUserName());
        }
        System.out.println("всего пользователей: " + userStorage.getAllUsers().size());
    }

    private static void addUser(UserStorage userStorage, Scanner scanner) {
        System.out.println("Введите имя пользователя:");
        String username = scanner.nextLine();
        User user = new User(username, null);
        userStorage.addUser(user);
        System.out.println("Пользователь " + username + " добавлен");
    }

    private static void sendMessage(UserStorage userStorage, Scanner scanner) {
        Message msg = Message.readFromConsole(scanner, userStorage);
        msg.getSender().sendMessage(msg.getCaption(), msg.getText(), msg.getReceiver());
        System.out.println("Сообщение отправлено");
    }

    private static void showInbox(UserStorage userStorage, Scanner scanner) {
        System.out.println("Введите имя пользователя для отображения входящих сообщений:");
        String username = scanner.nextLine();
        User user = userStorage.getUserByName(username);
        if (user != null) {
            System.out.println("Входящие сообщения для " + username + ":");
            if (user.getInbox().isEmpty()) {
                System.out.println("== Входящие сообщения отсутствуют ==");
            } else {
                for (Message message : user.getInbox()) {
                    System.out.println(message.getCaption() + ": " + message.getText());
                }
            }
        } else {
            throw new IllegalArgumentException("Пользователь не найден");
        }
    }

    private static void showOutbox(UserStorage userStorage, Scanner scanner) {
        System.out.println("Введите имя пользователя для отображения исходящих сообщений:");
        String username = scanner.nextLine();
        User user = userStorage.getUserByName(username);
        if (user != null) {
            System.out.println("Исходящие сообщения для " + username + ":");
            if (user.getOutbox().isEmpty()) {
                System.out.println("== Исходящие сообщения отсутствуют ==");
            } else {
                for (Message message : user.getOutbox()) {
                    System.out.println(message.getCaption() + ": " + message.getText());
                }
            }
        } else {
            throw new IllegalArgumentException("Пользователь не найден");
        }
    }

    private static void processSpam(UserStorage userStorage, Scanner scanner) {
        System.out.println("Введите имя пользователя для отображения спама:");
        String username = scanner.nextLine();
        User user = userStorage.getUserByName(username);
        if (user != null) {
            System.out.println("Спам для " + username + ":");
            if (user.getSpam().isEmpty()) {
                System.out.println("== Спам отсутствует ==");
            } else {
                for (Message message : user.getSpam()) {
                    System.out.println(message.getCaption() + ": " + message.getText());
                }
            }
        } else {
            throw new IllegalArgumentException("Пользователь не найден");
        }
    }

    private static void setFilter(UserStorage userStorage, Scanner scanner) {
        System.out.print("Введите имя пользователя для изменения фильтра: ");
        String username = scanner.nextLine().trim();
        User user = userStorage.getUserByName(username);
        if (user == null) throw new IllegalArgumentException("Пользователь не найден");
        System.out.println("Выберите один или несколько фильтров (simple, keywords, repetition, sender). Введите done для завершения:");
        while (true) {
            System.out.print("фильтр> ");
            String filterType = scanner.nextLine().trim().toLowerCase();
            if (filterType.equals("done")) break;
            SpamFilter filter;
            switch (filterType) {
                case "simple":
                    filter = new SimpleSpamFilter();
                    break;
                case "keywords":
                    System.out.print("Введите ключевые слова через запятую или пробелы: ");
                    String raw = scanner.nextLine().trim();
                    if (raw.isEmpty()) throw new IllegalArgumentException("Набор ключевых слов пуст");
                    String[] parts = raw.split("[\\s,]+");
                    Set<String> keywordSet = new HashSet<>();
                    for (String p : parts) {
                        String k = p.trim().toLowerCase();
                        if (!k.isEmpty()) keywordSet.add(k);
                    }
                    if (keywordSet.isEmpty()) throw new IllegalArgumentException("Набор ключевых слов пуст");
                    filter = new KeywordsSpamFilter(keywordSet);
                    break;
                case "repetition":
                    System.out.print("Введите максимальное число повторений одного слова: ");
                    String num = scanner.nextLine().trim();
                    int maxRep;
                    try {
                        maxRep = Integer.parseInt(num);
                    } catch (NumberFormatException ex) {
                        throw new IllegalArgumentException("Неверный формат числа");
                    }
                    if (maxRep <= 0) throw new IllegalArgumentException("Число должно быть положительным");
                    filter = new RepetitionSpamFilter(maxRep);
                    break;
                case "sender":
                    System.out.print("Введите имя отправителя для блокировки: ");
                    String senderName = scanner.nextLine().trim();
                    if (!userStorage.userExists(senderName)) {
                        throw new IllegalArgumentException("Такого отправителя не существует");
                    }
                    filter = new SenderSpamFilter(senderName);
                    break;
                default:
                    System.out.println("Неверный тип фильтра, попробуйте снова или введите done");
                    continue;
            }
            user.setSpamFilter(filter);
            System.out.println("Добавлен фильтр: " + filterType);
        }
        System.out.println("Настройка фильтров завершена для пользователя " + username);
    }
}