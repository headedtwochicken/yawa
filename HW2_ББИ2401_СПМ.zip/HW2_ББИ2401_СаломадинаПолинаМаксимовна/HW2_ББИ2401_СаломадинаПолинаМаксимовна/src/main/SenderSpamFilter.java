package main;

public class SenderSpamFilter implements SpamFilter {
    private String bannedSender;

    public SenderSpamFilter(String bannedSender) {
        this.bannedSender = bannedSender;
    }

    @Override
    public boolean isSpam(Message message) {
        return message.getSender().getUserName().equals(bannedSender);
    }
}