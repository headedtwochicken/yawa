package main;

import java.util.*;
public class CompositeSpamFilter implements SpamFilter {
    private final List<SpamFilter> filters;

    public CompositeSpamFilter(List<SpamFilter> filters) {
        this.filters = filters;
    }

    public void addFilter(SpamFilter filter) {
        filters.add(filter);
    }

    public List<SpamFilter> getFilters() {
        return Collections.unmodifiableList(filters);
    }

    @Override
    public boolean isSpam(Message message) {
        for (SpamFilter filter : filters) {
            if (filter.isSpam(message)) {
                return true;
            }
        }
        return false;
    }
}