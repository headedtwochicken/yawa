import java.math.BigInteger;
import java.util.*;

public class Main {
    private static final Map<String, BigInteger> variables = new HashMap<>();

    public static void main(String[] args) {
        for (int i = 1; i <= 5; i++) {
            variables.put("x" + i, BigInteger.ZERO);
        }
        System.out.println("Введите выражение в постфиксной нотации. Для выхода введите 'quit'");
        Scanner input = new Scanner(System.in);
        while (true) {
            System.out.print("—> ");
            String userLine = input.nextLine().trim();
            if (userLine.equalsIgnoreCase("quit")) {
                break;
            }
            if (userLine.equals("")) {
                System.out.println("Введите выражение");
                continue;
            }
            try {
                String[] tokens = userLine.split("\\s+");
                BigInteger result = expression(tokens);
                System.out.println(result);
            } catch (Exception ex) {
                System.out.println("Ошибка: " + ex.getMessage());
            }
        }
        System.out.println("Калькулятор завершён");
    }

    private static BigInteger expression(String[] tokens) {
        int index = Arrays.asList(tokens).indexOf("=");
        if (index != -1) {
            if (index != 1) {
                throw new IllegalArgumentException("Присваивание должно иметь следующий вид: переменная = выражение");
            }
            String variablesName = tokens[0];
            if (!variablesName.matches("[a-zA-Z_!№#$%@][a-zA-Z0-9_!№#$%@]*")) {
                throw new IllegalArgumentException("Некорректное имя переменной '" + variablesName + "'");
            }
            String[] expressions = Arrays.copyOfRange(tokens, 2, tokens.length);
            BigInteger res = polishEntry(expressions);
            variables.put(variablesName, res);
            return res;
        }
        return polishEntry(tokens);
    }

    private static BigInteger polishEntry(String[] tokens) {
        Deque<BigInteger> stack = new ArrayDeque<>();
        for (String token : tokens) {
            if (token.matches("\\d+")) {
                stack.push(new BigInteger(token));
            }
            else if (correctOperators(token)) {
                if (stack.size() < 2) {
                    throw new ArrayIndexOutOfBoundsException("Недостаточно операндов для оператора '" + token + "'");
                }
                BigInteger operand_2 = stack.pop();
                BigInteger operand_1 = stack.pop();
                stack.push(operators(token, operand_1, operand_2));
            }
            else if (variables.containsKey(token)) {
                stack.push(variables.get(token));
            }
            else if (incorrectOperators(token)) {
                throw new ArrayIndexOutOfBoundsException("Операция '" + token + "' не поддерживается");
            }
            else {
                throw new IllegalArgumentException("Неизвестный токен '" + token + "'");
            }
        }
        if (stack.size() != 1) {
            throw new ArrayIndexOutOfBoundsException("Некорректное выражение. Проверьте количество операндов и операторов");
        }
        return stack.pop();
    }

    private static boolean correctOperators(String token) {
        return token.equals("+") || token.equals("-") || token.equals("*") || token.equals("/");
    }

    private static boolean incorrectOperators(String token) {
        return token.equals("//") || token.equals("==") || token.equals("%") || token.equals("^");
    }

    private static BigInteger operators(String tock, BigInteger op1, BigInteger op2) {
        switch (tock) {
            case "+":
                return op1.add(op2);
            case "-":
                return op1.subtract(op2);
            case "*":
                return op1.multiply(op2);
            case "/":
                if (op2.equals(BigInteger.ZERO)) {
                    throw new ArithmeticException("Деление на ноль");
                }
                return op1.divide(op2);
            default:
                throw new IllegalArgumentException("Недопустимый оператор '" + tock + "'");
        }
    }
}