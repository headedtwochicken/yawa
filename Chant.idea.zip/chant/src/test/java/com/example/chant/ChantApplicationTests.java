package com.example.chant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChantApplicationTests {

	@Test
	void contextLoads() {
	}

}
