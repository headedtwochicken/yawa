package com.example.chant;

public class Post {
    private Long id;
    private String title;
    private String content;
    private int likes;

    public Post(Long id, String title, String content) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.likes = 0;
    }

    public Long getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }

    public int getLikes() {
        return likes;
    }

    public void like() {
        likes++;
    }
}
