package com.example.chant;

import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

@Service
public class PostService {
    private final Map<Long, Post> posts = new ConcurrentHashMap<>();
    private final AtomicLong idCounter = new AtomicLong(1);

    public List<Post> getAll() {
        return posts.values().stream()
                .sorted(Comparator.comparing(Post::getLikes).reversed())
                .toList();
    }

    public Post getById(Long id) {
        return posts.get(id);
    }

    public Post create(String title, String content) {
        Long id = idCounter.getAndIncrement();
        Post post = new Post(id, title, content);
        posts.put(id, post);
        return post;
    }

    public void like(Long id) {
        Post post = posts.get(id);
        if (post != null) {
            post.like();
        }
    }
}
