package com.example.chant;

import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/posts")
public class PostController {
    private final PostService service;

    public PostController(PostService service) {
        this.service = service;
    }

    @GetMapping
    public List<Post> getAll() {
        return service.getAll();
    }

    @PostMapping
    public Post create(@RequestBody Map<String, String> body) {
        String title = body.get("title");
        String content = body.get("content");
        return service.create(title, content);
    }

    @PostMapping("/{id}/like")
    public void like(@PathVariable Long id) {
        service.like(id);
    }
}
