package com.example.chant;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class PageController {
    private final PostService postService;

    public PageController(PostService postService) {
        this.postService = postService;
    }

    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("posts", postService.getAll());
        return "index";
    }

    @GetMapping("/create")
    public String createForm() {
        return "create";
    }

    @PostMapping("/create")
    public String createPost(@RequestParam String title, @RequestParam String content) {
        postService.create(title, content);
        return "redirect:/";
    }

    @PostMapping("/like/{id}")
    public String likePost(@PathVariable Long id) {
        postService.like(id);
        return "redirect:/";
    }
}
